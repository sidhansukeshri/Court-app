let caseNumberRadio = document.getElementById('caseNumberRadio');
let fillingNumberRadio = document.getElementById('fillingNumberRadio');
let caseNumberFields = document.getElementById('caseNumberFields');
let fillingNumberFields = document.getElementById('fillingNumberFields');
let awardTable = document.getElementById('awardTable');

caseNumberRadio.addEventListener('change', function() {
    if (caseNumberRadio.checked) {
        caseNumberFields.style.display = 'block';
        fillingNumberFields.style.display = 'none';
    }
});

fillingNumberRadio.addEventListener('change', function() {
    if (fillingNumberRadio.checked) {
        fillingNumberFields.style.display = 'block';
        caseNumberFields.style.display = 'none';
    }
});

document.getElementById('awardForm').addEventListener('submit', function(event) {
    // Your form submission logic here
    event.preventDefault(); // Prevents the default form submission behavior
    alert('Form submitted!');
});

document.getElementById('awardForm').addEventListener('reset', function() {
    // Your cancel logic here
    alert('Form canceled!');
});